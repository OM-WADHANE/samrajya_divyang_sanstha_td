# सम्राज्य दिव्यांग संस्था — Samrajya Divyang Sanstha
### Blue + Bhagwa (Orange) Theme | Vercel-Ready

---

## 📁 Project Structure

```
samrajya/
├── index.html          ← Main HTML file
├── css/
│   └── style.css       ← Blue + Orange (Bhagwa) theme styles
├── js/
│   └── main.js         ← All translations, render logic, form handler
├── vercel.json         ← Vercel deployment config
├── logo.jpeg           ← ⚠️ ADD YOUR LOGO HERE (rename to logo.jpeg)
└── README.md
```

---

## 🖼️ Adding Your Logo

Place your organization logo in the **root folder** and name it **`logo.jpeg`**.

If you want to use a different filename, update line 3 in `js/main.js`:
```js
const LOGO = './logo.jpeg'; // Change this path if needed
```

---

## 🚀 Deploy on Vercel

### Option 1 — Vercel Dashboard (Easiest)
1. Go to [vercel.com](https://vercel.com) and sign in
2. Click **"Add New Project"**
3. Upload this folder or connect your GitHub repo
4. Click **Deploy** — done!

### Option 2 — Vercel CLI
```bash
npm install -g vercel
cd samrajya
vercel
```

### Option 3 — GitHub + Vercel (Recommended for updates)
1. Push this folder to a GitHub repository
2. Connect the repo on Vercel dashboard
3. Every push auto-deploys 🎉

---

## ✏️ Customization

All content is in `js/main.js` inside the `T` object.
- `T.mr` → Marathi translations
- `T.en` → English translations

To change contact info, documents, or leadership names, edit the relevant fields in that object.

---

## 🎨 Theme Colors

Edit CSS variables in `css/style.css` (top of file):
- `--orange` / `--orange-mid` → Bhagwa / saffron shades
- `--blue` / `--navy` → Deep blue shades

---

Developed with ❤️ in India by [OM WADHANE](https://omwdev.netlify.app/)
