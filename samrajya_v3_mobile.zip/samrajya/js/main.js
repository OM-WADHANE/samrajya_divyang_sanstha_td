// ============================================================
// CONFIGURATION
// ============================================================
const LOGO = './logo.jpeg';

const T = {
  mr: {
    nav: { home: 'मुखपृष्ठ', about: 'संस्थेबद्दल', services: 'सेवा', docs: 'दस्तऐवज', contact: 'संपर्क' },
    banner: {
      title: 'संस्थेचे पदाधिकारी',
      pr: 'अध्यक्ष', tr: 'खजिनदार', sc: 'सचिव',
      pn: 'सुधाकर नंदवरम', tn: 'अविनाश ज्ञानदेव दोरगे', sn: 'किशोर कुलकर्णी'
    },
    hero: {
      badge: 'सेवा • समता • सन्मान',
      title: 'सम्राज्य दिव्यांग संस्था',
      sub: 'Samrajya Divyang Sanstha',
      desc: 'दिव्यांग व्यक्तींच्या सक्षमीकरणासाठी कार्यरत एक समर्पित संस्था. आम्ही समान संधी, सम्मान आणि स्वावलंबन यासाठी प्रतिबद्ध आहोत.',
      b1: 'अधिक जाणून घ्या', b2: 'दस्तऐवज पहा',
      s1: 'वर्षे', s2: 'सदस्य', s3: 'उपक्रम'
    },
    about: {
      tag: 'आमच्याबद्दल', title: 'आमची ओळख आणि उद्देश',
      desc: 'सम्राज्य दिव्यांग संस्था ही दिव्यांग व्यक्तींच्या कल्याणासाठी, त्यांच्या हक्कांच्या संरक्षणासाठी आणि सामाजिक एकात्मतेसाठी निरंतर कार्य करणारी संस्था आहे.',
      i1: '🎯', i1t: 'आमचे ध्येय', i1d: 'दिव्यांग व्यक्तींना समाजात समान दर्जा मिळवून देणे.',
      i2: '🌱', i2t: 'आमचे कार्य', i2d: 'शासकीय योजना, प्रशिक्षण व सहाय्याद्वारे जीवनमान सुधारणे.',
      i3: '⚖️', i3t: 'आमचे मूल्य', i3d: 'पारदर्शकता, सेवा आणि सामाजिक न्याय.'
    },
    services: {
      tag: 'सेवा', title: 'आम्ही काय करतो', desc: 'आम्ही दिव्यांग व्यक्तींना विविध स्तरांवर मदत करतो.',
      s: [
        { i: '📋', t: 'नोंदणी सहाय्य',      d: 'दिव्यांग प्रमाणपत्र व शासकीय नोंदणी मार्गदर्शन' },
        { i: '💼', t: 'रोजगार मार्गदर्शन',   d: 'व्यावसायिक प्रशिक्षण व नोकरी संधी' },
        { i: '📚', t: 'शैक्षणिक सहाय्य',     d: 'शिष्यवृत्ती व शैक्षणिक कार्यक्रम' },
        { i: '⚖️', t: 'हक्क जागृती',         d: 'कायदेशीर हक्कांची माहिती' },
        { i: '🏥', t: 'आरोग्य सेवा',         d: 'वैद्यकीय मदत व पुनर्वसन' },
        { i: '🤝', t: 'समाज एकात्मता',       d: 'सांस्कृतिक कार्यक्रम व सहभाग' }
      ]
    },
    docs: {
      tag: 'दस्तऐवज', title: 'महत्त्वाचे दस्तऐवज', desc: 'खालील दस्तऐवज उघडण्यासाठी बटणावर क्लिक करा.',
      d: [
        { ic: '📝', t: 'सभासद नोंदणी फॉर्म',      s: 'Membership Registration Form',  l: 'https://drive.google.com/file/d/1MMw97JNsmzhb6kUbUuWrU3CU5t_pX_L-/view?usp=drive_link' },
        { ic: '🖨️', t: 'लेटर हेड',                s: 'Official Letter Head',           l: 'https://drive.google.com/file/d/1pzLYbh3bOu5fqu8rfu5o-vGLPjLaLb-I/view?usp=drive_link' },
        { ic: '🧾', t: 'पावती / सभासद शुल्क पावती', s: 'Membership Fee Receipt',         l: 'https://drive.google.com/file/d/1SYx2oHzG2mriCyFSBKrMF6tjxSZqdWM2/view?usp=drive_link' }
      ],
      btn: 'उघडा ↗'
    },
    contact: {
      tag: 'संपर्क', title: 'आमच्याशी संपर्क साधा', desc: 'आपल्या प्रश्नांसाठी किंवा अधिक माहितीसाठी संपर्क करा.',
      a: 'पत्ता', av: 'के. ऑफ 4851, सुधाकर नंदवरम,\nसंभाजी नगर, मराठशाळे मागे,\nतळेगाव दाभाडे, ता. मावळ,\nजि. पुणे – 410506',
      r: 'नोंदणी क्र.', rv: 'Pune/0001459/2023',
      p: 'दूरध्वनी', pv: '9561836678',
      e: 'ई-मेल', ev: 'samrajyawelfare@gmail.com',
      ft: 'संदेश पाठवा', fn: 'आपले नाव', fe: 'ईमेल पत्ता', fm: 'आपला संदेश', fs: 'पाठवा',
      sent: 'संदेश यशस्वीरीत्या पाठवला! धन्यवाद.'
    },
    footer: {
      copy: '© 2026 सम्राज्य दिव्यांग संस्था. सर्व हक्क राखीव.',
      lh: 'त्वरित दुवे', ll: ['मुखपृष्ठ', 'संस्थेबद्दल', 'सेवा', 'दस्तऐवज', 'संपर्क']
    }
  },
  en: {
    nav: { home: 'Home', about: 'About', services: 'Services', docs: 'Documents', contact: 'Contact' },
    banner: {
      title: 'Organization Leadership',
      pr: 'President', tr: 'Treasurer', sc: 'Secretary',
      pn: 'Sudhakar Nandavaram', tn: 'Avinash Dnyandev Dorge', sn: 'Kishor Kulkarni'
    },
    hero: {
      badge: 'Service • Equality • Dignity',
      title: 'Samrajya Divyang Sanstha',
      sub: 'सम्राज्य दिव्यांग संस्था',
      desc: 'A dedicated organization working for the empowerment of persons with disabilities. Committed to equal opportunities, dignity, and self-reliance.',
      b1: 'Learn More', b2: 'View Documents',
      s1: 'Years', s2: 'Members', s3: 'Initiatives'
    },
    about: {
      tag: 'About Us', title: 'Our Identity & Purpose',
      desc: 'Samrajya Divyang Sanstha continuously works for the welfare of persons with disabilities, protection of their rights, and social integration.',
      i1: '🎯', i1t: 'Our Mission', i1d: 'To ensure equal status for persons with disabilities in society.',
      i2: '🌱', i2t: 'Our Work',    i2d: 'Improving livelihoods through government schemes, training and support.',
      i3: '⚖️', i3t: 'Our Values',  i3d: 'Transparency, service, and social justice.'
    },
    services: {
      tag: 'Services', title: 'What We Do', desc: 'We support persons with disabilities at various levels.',
      s: [
        { i: '📋', t: 'Registration Assistance', d: 'Disability certificate & govt. registration guidance' },
        { i: '💼', t: 'Employment Guidance',     d: 'Vocational training & job opportunities' },
        { i: '📚', t: 'Educational Support',     d: 'Scholarships & educational programs' },
        { i: '⚖️', t: 'Rights Awareness',        d: 'Legal rights information' },
        { i: '🏥', t: 'Health Services',         d: 'Medical aid & rehabilitation' },
        { i: '🤝', t: 'Social Integration',      d: 'Cultural programs & participation' }
      ]
    },
    docs: {
      tag: 'Documents', title: 'Important Documents', desc: 'Click the button to open any document.',
      d: [
        { ic: '📝', t: 'Membership Form',        s: 'सभासद नोंदणी फॉर्म',          l: 'https://drive.google.com/file/d/1MMw97JNsmzhb6kUbUuWrU3CU5t_pX_L-/view?usp=drive_link' },
        { ic: '🖨️', t: 'Letter Head',            s: 'लेटर हेड',                    l: 'https://drive.google.com/file/d/1pzLYbh3bOu5fqu8rfu5o-vGLPjLaLb-I/view?usp=drive_link' },
        { ic: '🧾', t: 'Membership Fee Receipt', s: 'पावती / सभासद शुल्क पावती',   l: 'https://drive.google.com/file/d/1SYx2oHzG2mriCyFSBKrMF6tjxSZqdWM2/view?usp=drive_link' }
      ],
      btn: 'Open ↗'
    },
    contact: {
      tag: 'Contact', title: 'Get In Touch', desc: 'Contact us for your queries or for more information.',
      a: 'Address', av: 'K. Off 4851, Sudhakar Nandavaram,\nSambhaji Nagar, Behind Maratha Shala,\nTalegaon Dabhade, Ta. Maval,\nDist. Pune – 410506',
      r: 'Registration No.', rv: 'Pune/0001459/2023',
      p: 'Phone', pv: '9561836678',
      e: 'Email', ev: 'samrajyawelfare@gmail.com',
      ft: 'Send a Message', fn: 'Your Name', fe: 'Email Address', fm: 'Your Message', fs: 'Send Message',
      sent: 'Message sent successfully! Thank you.'
    },
    footer: {
      copy: '© 2026 Samrajya Divyang Sanstha. All rights reserved.',
      lh: 'Quick Links', ll: ['Home', 'About', 'Services', 'Documents', 'Contact']
    }
  }
};

// ============================================================
// STATE
// ============================================================
const ids = ['home', 'about', 'services', 'docs', 'contact'];
let lang = 'mr';
let darkMode = false;

// ============================================================
// DARK MODE
// ============================================================
function toggleDark() {
  darkMode = !darkMode;
  document.body.classList.toggle('dark', darkMode);
  // persist preference
  localStorage.setItem('sds-dark', darkMode ? '1' : '0');
}

function initDarkMode() {
  const saved = localStorage.getItem('sds-dark');
  if (saved === '1') {
    darkMode = true;
    document.body.classList.add('dark');
  }
}

// ============================================================
// NAVIGATION
// ============================================================
function go(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function setL(l) {
  lang = l;
  render();
}

// ============================================================
// MOBILE MENU
// ============================================================
function toggleMenu() {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger');
  if (!menu) return;
  const open = menu.classList.toggle('open');
  if (btn) btn.classList.toggle('open', open);
}
function closeMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  const btn  = document.getElementById('hamburger');
  if (menu) menu.classList.remove('open');
  if (btn)  btn.classList.remove('open');
}

function initScroll() {
  let lastY = window.scrollY;
  window.onscroll = () => {
    const nav = document.getElementById('navbar');
    if (!nav) return;
    const y = window.scrollY;
    if (y > lastY && y > 90) {
      nav.classList.add('hidden');
      nav.classList.remove('visible');
    } else {
      nav.classList.remove('hidden');
      nav.classList.add('visible');
    }
    lastY = y;
  };
}

// ============================================================
// CONTACT FORM
// ============================================================
function sendMail() {
  const name  = document.getElementById('f-name').value.trim();
  const email = document.getElementById('f-email').value.trim();
  const msg   = document.getElementById('f-msg').value.trim();
  const l = T[lang];
  if (!name || !msg) {
    alert(lang === 'mr' ? 'कृपया नाव आणि संदेश भरा.' : 'Please fill your name and message.');
    return;
  }
  const subject = encodeURIComponent((lang === 'mr' ? 'संस्थेकडून संदेश: ' : 'Message from website: ') + name);
  const body = encodeURIComponent(
    (lang === 'mr' ? 'नाव: ' : 'Name: ') + name + '\n' +
    (lang === 'mr' ? 'ईमेल: ' : 'Email: ') + email + '\n\n' +
    (lang === 'mr' ? 'संदेश:\n' : 'Message:\n') + msg
  );
  window.open('mailto:samrajyawelfare@gmail.com?subject=' + subject + '&body=' + body, '_blank');
  const m = document.getElementById('form-msg');
  m.style.display = 'block';
  m.textContent = l.contact.sent;
  setTimeout(() => { m.style.display = 'none'; }, 4000);
}

// ============================================================
// RENDER
// ============================================================
function render() {
  const l = T[lang];
  const m = lang === 'mr' ? 'mr' : '';
  const navKeys = Object.values(l.nav);

  document.getElementById('app').innerHTML = `

<!-- ══════════ NAVBAR ══════════ -->
<nav id="navbar" class="visible">
  <div class="nav-brand">
    <div class="nav-logo-wrap">
      <img class="nav-logo-img" src="${LOGO}" alt="Logo" onerror="this.style.display='none'"/>
    </div>
    <div class="nav-text-wrap">
      <div class="nav-name">सम्राज्य दिव्यांग संस्था</div>
      <div class="nav-name-en">Samrajya Divyang Sanstha</div>
    </div>
  </div>

  <!-- Desktop nav links (hidden on mobile) -->
  <div class="nav-links desktop-only">
    ${ids.map((id, i) => `<button class="nav-link" onclick="go('${id}')">${navKeys[i]}</button>`).join('')}
  </div>

  <!-- Right side: lang + dark toggle (always visible) -->
  <div class="nav-right">
    <div class="lang-toggle">
      <button class="lang-btn ${lang === 'mr' ? 'act' : ''}" onclick="setL('mr')">मर</button>
      <button class="lang-btn ${lang === 'en' ? 'act' : ''}" onclick="setL('en')">EN</button>
    </div>
    <div class="dark-toggle" onclick="toggleDark()" title="Toggle dark mode">
      <div class="dark-toggle-knob">${darkMode ? '🌙' : '☀️'}</div>
    </div>
    <!-- Hamburger (mobile only) -->
    <button class="hamburger mobile-only" onclick="toggleMenu()" id="hamburger" aria-label="Menu">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<!-- Mobile dropdown menu -->
<div class="mobile-menu" id="mobile-menu">
  ${ids.map((id, i) => `<button class="mobile-nav-link" onclick="go('${id}');closeMobileMenu()">${navKeys[i]}</button>`).join('')}
</div>

<!-- ══════════ LEADERSHIP BANNER ══════════ -->
<div class="lbanner">
  <div class="lb-title">${l.banner.title}</div>
  <div class="lb-item"><span class="lb-role">${l.banner.pr}</span><span class="${m}">${l.banner.pn}</span></div>
  <div class="lb-item"><span class="lb-role">${l.banner.tr}</span><span class="${m}">${l.banner.tn}</span></div>
  <div class="lb-item"><span class="lb-role">${l.banner.sc}</span><span class="${m}">${l.banner.sn}</span></div>
</div>

<!-- ══════════ HERO ══════════ -->
<div id="home" class="st">
  <div class="hero">
    <div class="hero-bg"></div>
    <div class="hero-corners"></div>
    <div class="hero-inner">
      <img class="hero-logo" src="${LOGO}" alt="Samrajya Divyang Sanstha Logo" onerror="this.style.display='none'"/>
      <div class="hero-badge">${l.hero.badge}</div>
      <h1 class="hero-title ${m}">${l.hero.title}</h1>
      <p class="hero-sub">${l.hero.sub}</p>
      <p class="hero-desc ${m}">${l.hero.desc}</p>
      <div class="hero-btns">
        <button class="btn-p" onclick="go('about')">${l.hero.b1}</button>
        <button class="btn-o" onclick="go('docs')">${l.hero.b2}</button>
      </div>
      <div class="hero-stats">
        <div class="stat"><div class="num">10+</div><div class="lbl">${l.hero.s1}</div></div>
        <div class="stat"><div class="num">500+</div><div class="lbl">${l.hero.s2}</div></div>
        <div class="stat"><div class="num">50+</div><div class="lbl">${l.hero.s3}</div></div>
      </div>
    </div>
  </div>
</div>

<!-- ══════════ ABOUT ══════════ -->
<div id="about" class="st">
  <div class="sec">
    <span class="sec-tag">${l.about.tag}</span>
    <h2 class="sec-title ${m}">${l.about.title}</h2>
    <div class="divider"></div>
    <div class="about-grid">
      <div class="about-text">
        <p class="${m}">${l.about.desc}</p>
        <p class="${m}" style="font-size:14px;color:var(--text-mid);line-height:1.85">
          तळेगाव दाभाडे, ता. मावळ, जि. पुणे येथे कार्यरत असलेली ही संस्था दिव्यांग व्यक्तींसाठी विविध उपक्रम राबवते आणि शासकीय योजनांची माहिती देते.
        </p>
      </div>
      <div class="about-panel">
        <div class="av-item">
          <div class="av-icon">${l.about.i1}</div>
          <div><div class="av-h ${m}">${l.about.i1t}</div><div class="av-p ${m}">${l.about.i1d}</div></div>
        </div>
        <div class="av-item">
          <div class="av-icon">${l.about.i2}</div>
          <div><div class="av-h ${m}">${l.about.i2t}</div><div class="av-p ${m}">${l.about.i2d}</div></div>
        </div>
        <div class="av-item">
          <div class="av-icon">${l.about.i3}</div>
          <div><div class="av-h ${m}">${l.about.i3t}</div><div class="av-p ${m}">${l.about.i3d}</div></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ══════════ SERVICES ══════════ -->
<div id="services" class="st">
  <div class="sec-bg-navy">
    <div class="sec-inner">
      <span class="sec-tag sec-tag-lt">${l.services.tag}</span>
      <h2 class="sec-title sec-title-lt ${m}">${l.services.title}</h2>
      <div class="divider divider-lt"></div>
      <p class="sec-desc sec-desc-lt ${m}">${l.services.desc}</p>
      <div class="srv-grid">
        ${l.services.s.map(s => `
          <div class="srv-card">
            <div class="srv-icon">${s.i}</div>
            <div class="srv-t ${m}">${s.t}</div>
            <div class="srv-d ${m}">${s.d}</div>
          </div>
        `).join('')}
      </div>
    </div>
  </div>
</div>

<!-- ══════════ DOCUMENTS ══════════ -->
<div id="docs" class="st">
  <div class="sec-bg-orange">
    <div class="sec-inner">
      <span class="sec-tag">${l.docs.tag}</span>
      <h2 class="sec-title ${m}">${l.docs.title}</h2>
      <div class="divider"></div>
      <p class="sec-desc ${m}">${l.docs.desc}</p>
      <div class="doc-grid">
        ${l.docs.d.map(d => `
          <div class="doc-card">
            <div class="doc-icon">${d.ic}</div>
            <div class="doc-t ${m}">${d.t}</div>
            <div class="doc-s">${d.s}</div>
            <a href="${d.l}" target="_blank" rel="noopener" class="doc-btn">${l.docs.btn}</a>
          </div>
        `).join('')}
      </div>
    </div>
  </div>
</div>

<!-- ══════════ CONTACT ══════════ -->
<div id="contact" class="st">
  <div class="sec">
    <span class="sec-tag">${l.contact.tag}</span>
    <h2 class="sec-title ${m}">${l.contact.title}</h2>
    <div class="divider"></div>
    <p class="sec-desc ${m}" style="margin-bottom:1.5rem">${l.contact.desc}</p>
    <div class="contact-grid">
      <div class="contact-cards">
        <div class="cc">
          <div class="cc-icon">📍</div>
          <div>
            <div class="cc-lbl">${l.contact.a}</div>
            <div class="cc-val ${m}">${l.contact.av.replace(/\n/g, '<br/>')}</div>
          </div>
        </div>
        <div class="cc">
          <div class="cc-icon">🏛️</div>
          <div>
            <div class="cc-lbl">${l.contact.r}</div>
            <div class="cc-val"><span class="reg">${l.contact.rv}</span></div>
          </div>
        </div>
        <div class="cc">
          <div class="cc-icon">📞</div>
          <div>
            <div class="cc-lbl">${l.contact.p}</div>
            <div class="cc-val"><a href="tel:+91${l.contact.pv}">${l.contact.pv}</a></div>
          </div>
        </div>
        <div class="cc">
          <div class="cc-icon">✉️</div>
          <div>
            <div class="cc-lbl">${l.contact.e}</div>
            <div class="cc-val"><a href="mailto:${l.contact.ev}">${l.contact.ev}</a></div>
          </div>
        </div>
      </div>
      <div class="cform">
        <div class="cform-t ${m}">${l.contact.ft}</div>
        <div class="fg">
          <label class="flbl">${l.contact.fn}</label>
          <input id="f-name" class="finp" type="text" placeholder="${l.contact.fn}"/>
        </div>
        <div class="fg">
          <label class="flbl">${l.contact.fe}</label>
          <input id="f-email" class="finp" type="email" placeholder="${l.contact.fe}"/>
        </div>
        <div class="fg">
          <label class="flbl">${l.contact.fm}</label>
          <textarea id="f-msg" class="ftxt" placeholder="${l.contact.fm}"></textarea>
        </div>
        <button class="fsub" onclick="sendMail()">${l.contact.fs}</button>
        <div id="form-msg" class="form-msg"></div>
      </div>
    </div>
  </div>
</div>

<!-- ══════════ FOOTER ══════════ -->
<footer>
  <div class="foot-inner">
    <div class="foot-brand">
      <img class="foot-logo" src="${LOGO}" alt="Logo" onerror="this.style.display='none'"/>
      <h3>सम्राज्य दिव्यांग संस्था</h3>
      <p>Samrajya Divyang Sanstha<br/>तळेगाव दाभाडे, ता. मावळ, जि. पुणे – 410506<br/>Reg. No: Pune/0001459/2023<br/>samrajyawelfare@gmail.com</p>
    </div>
    <div class="foot-links">
      <h4>${l.footer.lh}</h4>
      <ul>${l.footer.ll.map((lk, i) => `<li onclick="go('${ids[i]}')">${lk}</li>`).join('')}</ul>
    </div>
  </div>
  <div class="foot-bottom">
    <span class="foot-copy ${m}">${l.footer.copy}</span>
    <span class="foot-dev">Developed with ❤️ in India by <a href="https://omwdev.netlify.app/" target="_blank" rel="noopener">OM WADHANE</a></span>
  </div>
</footer>
  `;

  initScroll();
}

// ============================================================
// INIT
// ============================================================
initDarkMode();
render();
